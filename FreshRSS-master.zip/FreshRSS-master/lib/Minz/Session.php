<?php


class Minz_Session {
	
	public static function init($name) {
		$cookie = session_get_cookie_params();
		self::keepCookie($cookie['lifetime']);

		
		session_name($name);
		session_start();
	}


	
	public static function param($p, $default = false) {
		return isset($_SESSION[$p]) ? $_SESSION[$p] : $default;
	}


	public static function _param($p, $v = false) {
		if ($v === false) {
			unset($_SESSION[$p]);
		} else {
			$_SESSION[$p] = $v;
		}
	}


	
	public static function unset_session($force = false) {
		$language = self::param('language');

		session_destroy();
		$_SESSION = array();

		if (!$force) {
			self::_param('language', $language);
			Minz_Translate::reset($language);
		}
	}

	public static function getCookieDir() {
		
		$cookie_dir = empty($_SERVER['REQUEST_URI']) ? '/' : $_SERVER['REQUEST_URI'];
		if (substr($cookie_dir, -1) !== '/') {
			$cookie_dir = dirname($cookie_dir) . '/';
		}
		return $cookie_dir;
	}

	public static function keepCookie($l) {
		session_set_cookie_params($l, self::getCookieDir(), '', Minz_Request::isHttps(), true);
	}


	
	public static function regenerateID() {
		session_regenerate_id(true);
	}

	public static function deleteLongTermCookie($name) {
		setcookie($name, '', 1, '', '', Minz_Request::isHttps(), true);
	}

	public static function setLongTermCookie($name, $value, $expire) {
		setcookie($name, $value, $expire, '', '', Minz_Request::isHttps(), true);
	}

	public static function getLongTermCookie($name) {
		return isset($_COOKIE[$name]) ? $_COOKIE[$name] : null;
	}

}
