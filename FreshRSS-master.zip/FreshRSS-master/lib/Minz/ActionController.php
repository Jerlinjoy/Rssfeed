<?php

class Minz_ActionController {
	protected $view;

	
	public function __construct () {
		$this->view = new Minz_View ();
		$this->view->attributeParams ();
	}

	
	public function view () {
		return $this->view;
	}


	public function init () { }
	public function firstAction () { }
	public function lastAction () { }
}
