<?php

class Minz_Model {

}
