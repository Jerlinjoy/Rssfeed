<?php

class Minz_Paginator {
	
	private $items = array ();

	
	private $nbItemsPerPage = 10;

	
	private $currentPage = 1;


	private $nbPage = 1;

	
	private $nbItems = 0;

	
	public function __construct ($items) {
		$this->_items ($items);
		$this->_nbItems (count ($this->items (true)));
		$this->_nbItemsPerPage ($this->nbItemsPerPage);
		$this->_currentPage ($this->currentPage);
	}

	
	public function render ($view, $getteur) {
		$view = APP_PATH . '/views/helpers/'.$view;

		if (file_exists ($view)) {
			include ($view);
		}
	}

	
	public function pageByItem ($item) {
		$page = false;
		$i = 0;

		do {
			if ($item == $this->items[$i]) {
				$page = ceil (($i + 1) / $this->nbItemsPerPage);
			}

			$i++;
		} while (!$page && $i < $this->nbItems ());

		return $page;
	}

	
	public function positionByItem ($item) {
		$find = false;
		$i = 0;

		do {
			if ($item == $this->items[$i]) {
				$find = true;
			} else {
				$i++;
			}
		} while (!$find && $i < $this->nbItems ());

		return $i;
	}

	
	public function itemByPosition ($pos) {
		if ($pos < 0) {
			$pos = $this->nbItems () - 1;
		}
		if ($pos >= count($this->items)) {
			$pos = 0;
		}

		return $this->items[$pos];
	}

	
	public function items ($all = false) {
		$array = array ();
		$nbItems = $this->nbItems ();

		if ($nbItems <= $this->nbItemsPerPage || $all) {
			$array = $this->items;
		} else {
			$begin = ($this->currentPage - 1) * $this->nbItemsPerPage;
			$counter = 0;
			$i = 0;

			foreach ($this->items as $key => $item) {
				if ($i >= $begin) {
					$array[$key] = $item;
					$counter++;
				}
				if ($counter >= $this->nbItemsPerPage) {
					break;
				}
				$i++;
			}
		}

		return $array;
	}
	public function nbItemsPerPage  () {
		return $this->nbItemsPerPage;
	}
	public function currentPage () {
		return $this->currentPage;
	}
	public function nbPage () {
		return $this->nbPage;
	}
	public function nbItems () {
		return $this->nbItems;
	}

	public function _items ($items) {
		if (is_array ($items)) {
			$this->items = $items;
		}

		$this->_nbPage ();
	}
	public function _nbItemsPerPage ($nbItemsPerPage) {
		if ($nbItemsPerPage > $this->nbItems ()) {
			$nbItemsPerPage = $this->nbItems ();
		}
		if ($nbItemsPerPage < 0) {
			$nbItemsPerPage = 0;
		}

		$this->nbItemsPerPage = $nbItemsPerPage;
		$this->_nbPage ();
	}
	public function _currentPage ($page) {
		if($page < 1 || ($page > $this->nbPage && $this->nbPage > 0)) {
			throw new CurrentPagePaginationException ($page);
		}

		$this->currentPage = $page;
	}
	private function _nbPage () {
		if ($this->nbItemsPerPage > 0) {
			$this->nbPage = ceil ($this->nbItems () / $this->nbItemsPerPage);
		}
	}
	public function _nbItems ($value) {
		$this->nbItems = $value;
	}
}
