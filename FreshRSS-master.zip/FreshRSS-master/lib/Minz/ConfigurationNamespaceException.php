<?php

class Minz_ConfigurationNamespaceException extends Minz_ConfigurationException {
}
