# FreshRSS - API compatible Fever

Voir la page [sur notre API compatible Google Reader](06_Mobile_access.md) pour une autre possibilité
et des généralités sur l’accès par API.

## Compatibilité

Testé avec:

- iOS
  - [Fiery Feeds](https://itunes.apple.com/app/fiery-feeds-rss-reader/id1158763303)
  - [Unread](https://itunes.apple.com/app/unread-rss-reader/id1252376153)
  - [Reeder-3](https://itunes.apple.com/app/reeder-3/id697846300)

- MacOS
  - [Readkit](https://itunes.apple.com/app/readkit/id588726889)

## TODO

Voir [la page en anglais](../../en/users/06_Fever_API.md).
