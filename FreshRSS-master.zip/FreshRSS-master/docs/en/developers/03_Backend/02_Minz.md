# Models

**TODO**

# Controllers and actions

**TODO**

# Views

**TODO**

# Routing

**TODO**

# Writing URL

**TODO**

# Internationalisation

**TODO**

# Understanding internals

**TODO**
