FreshRSS-base-theme
===================

A base theme for [FreshRSS](https://freshrss.org)

1. Custom ```base.css``` file with colors, backgrounds and borders
2. Change information in ```metadata.json``` file (at least, give a name!)
3. Choose your new theme in FreshRSS configuration
4. Enjoy your wonderful theme!

Don't hesitate to share your theme with us [on Github](https://github.com/FreshRSS/FreshRSS/issues) :)

