Screwdriver 
=======

**C'est un cocktail! C'est chaud mais "fresh" à la fois. C'est... c'est... un thème pour l'agrégateur de flux RSS<a href="https://github.com/FreshRSS/FreshRSS/" target="blank">FreshRSS</a>!!**
En toute modestie, ce thème tue du chaton.

![screenshot](https://github.com/misterair/Screwdriver/blob/master/screenshot.png)


Installation
-----------------
1. Placez le dossier du thème dans ledossier /FreshRSS/p/themes/Screwdriver de votre FreshRSS;
2. Allez dans les paramètres d'Affichage et changez de thème;
3. Profitez de votre Screwdriver!
4. Remontez les problèmes sur Github (facultatif mais fortement apprécié)



Screwdriver est distribué sous license BeerWare:
-----------------

« LICENCE BEERWARE » (Révision 42):

mister.air@gmail.com a créé ce fichier. Tant que vous conservez cet avertissement,

vous pouvez faire ce que vous voulez de ce truc. Si on se rencontre un jour et

que vous pensez que ce truc vaut le coup, vous pouvez me payer une bière en retour.

*Mister aiR*






