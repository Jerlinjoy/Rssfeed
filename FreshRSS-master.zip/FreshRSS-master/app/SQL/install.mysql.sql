CREATE TABLE  category(
	`id` SMALLINT NOT NULL ,	-- v0.7
	`name` VARCHAR(40) NOT NULL,	-- Max index length for Unicode is 191 characters (767 bytes)
	PRIMARY KEY (`id`),
	UNIQUE KEY (`name`)	-- v0.7
) DEFAULT  CHARSET=utf8
ENGINE=MyISAM ;



CREATE TABLE feed (
	`id` SMALLINT NOT NULL AUTO_INCREMENT,	-- v0.7
	`url` VARCHAR(511) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
	`category` SMALLINT DEFAULT 0,	-- v0.7
	`name` VARCHAR(40) NOT NULL,
	`website` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_bin,
	`description` TEXT,
	`lastUpdate` INT(11) DEFAULT 0,	-- Until year 2038
	`priority` TINYINT(2) NOT NULL DEFAULT 10,
	`pathEntries` VARCHAR(511) DEFAULT NULL,
	`httpAuth` VARCHAR(511) DEFAULT NULL,
	`error` BOOLEAN DEFAULT 0,
	`keep_history` MEDIUMINT NOT NULL DEFAULT -2,	-- v0.7
	`ttl` INT NOT NULL DEFAULT 0,	-- v0.7.3
	`attributes` TEXT,	-- v1.11.0
	`cache_nbEntries` INT DEFAULT 0,	-- v0.7
	`cache_nbUnreads` INT DEFAULT 0,	-- v0.7
	PRIMARY KEY (`id`),
	UNIQUE KEY (`url`),	-- v0.7
	INDEX (`name`),	-- v0.7
	INDEX (`priority`),	-- v0.7
	INDEX (`keep_history`)	-- v0.7
) DEFAULT CHARACTER SET utf8mb4
ENGINE = INNODB;

CREATE TABLE entry (
	`id` BIGINT NOT NULL,	-- v0.7
	`guid` VARCHAR(760) NOT NULL,	-- Maximum for UNIQUE is 767B
	`title` VARCHAR(255) NOT NULL,
	`author` VARCHAR(255),
	`content_bin` BLOB,	-- v0.7
	`link` VARCHAR(1023) NOT NULL,
	`date` INT(11),	-- Until year 2038
	`lastSeen` INT(11) DEFAULT 0,	-- v1.1.1, Until year 2038
	`hash` BINARY(16),	-- v1.1.1
	`is_read` BOOLEAN NOT NULL DEFAULT 0,
	`is_favorite` BOOLEAN NOT NULL DEFAULT 0,
	`id_feed` SMALLINT,	-- v0.7
	`tags` VARCHAR(1023),
	PRIMARY KEY (`id`),
	UNIQUE KEY (`id_feed`,`guid`),	-- v0.7
	INDEX (`is_favorite`),	-- v0.7
	INDEX (`is_read`),	-- v0.7
	INDEX `entry_lastSeen_index` (`lastSeen`)	-- v1.1.1
	-- INDEX `entry_feed_read_index` (`id_feed`,`is_read`)	-- v1.7 Located futher down
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
ENGINE = INNODB;

INSERT IGNORE INTO category (id, name) VALUES(1, "%2$s");





CREATE TABLE entrytmp (	-- v1.7
	`id` BIGINT NOT NULL,
	`guid` VARCHAR(760) NOT NULL,
	`title` VARCHAR(255) NOT NULL,
	`author` VARCHAR(255),
	`content_bin` BLOB,
	`link` VARCHAR(1023) NOT NULL,
	`date` INT(11),
	`lastSeen` INT(11) DEFAULT 0,
	`hash` BINARY(16),
	`is_read` BOOLEAN NOT NULL DEFAULT 0,
	`is_favorite` BOOLEAN NOT NULL DEFAULT 0,
	`id_feed` SMALLINT,
	`tags` VARCHAR(1023),
	PRIMARY KEY (`id`),
	UNIQUE KEY (`id_feed`,`guid`),
	INDEX (`date`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
ENGINE = INNODB;


CREATE INDEX `read_index` ON `entry`(`id_feed`,`is_read`);	


CREATE TABLE tag (
	`id` SMALLINT NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(63) NOT NULL,
	`attributes` TEXT,
	PRIMARY KEY (`id`),
	UNIQUE KEY (`name`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
ENGINE = INNODB;

CREATE TABLE entrytag (
	`id_tag` SMALLINT,
	`id_entry` BIGINT,
	PRIMARY KEY (`id_tag`,`id_entry`),
	INDEX (`id_entry`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
ENGINE = INNODB;


INSERT IGNORE INTO `feed` (url, category, name, website, description, ttl) VALUES("https://www.catholicnewsagency.com/rss/", 1, "RSS.org", "https://www.catholicnewsagency.com/rss/", "CNA", 86400);
INSERT IGNORE INTO `feed` (url, category, name, website, description, ttl) VALUES("http://feeds.reuters.com/reuters/topNews", 1, "Reuters.org", "http://feeds.reuters.com/reuters/topNews", "reuters", 86400);
