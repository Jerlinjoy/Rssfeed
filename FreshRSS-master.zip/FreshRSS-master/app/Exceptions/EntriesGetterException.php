<?php

class FreshRSS_EntriesGetter_Exception extends Exception {

}
