<?php

class FreshRSS_Feed_Exception extends Exception {

}
