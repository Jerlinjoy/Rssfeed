<?php
 return array (
  'salt' => '26360a13f1393e1fbe84b98bf0bf1c9c2338829d',
  'base_url' => 'http://localhost/freshRSS-master/p',
  'title' => 'FreshRSS',
  'default_user' => 'root',
  'auth_type' => 'form',
  'db' => 
  array (
    'type' => 'mysql',
    'host' => 'localhost',
    'user' => 'root',
    'password' => 'localhost',
    'base' => 'rss',
    'prefix' => 'rss_',
    'pdo_options' => 
    array (
    ),
  ),
  'pubsubhubbub_enabled' => false,
);
