# FreshRSS extensions

You may place custom extensions for FreshRSS in this directory.

You can find some extensions in our [GitHub repository](https://github.com/FreshRSS/Extensions).
